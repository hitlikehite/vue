<template>
  <div class="bar-box">
    <p>Bar 组件</p>
  </div>
</template>

<script>
export default {
  // name: '',
  data () {
    return {}
  }
}
</script>

<style scoped>
.bar-box {
  padding: 5px;
  border: 1px solid #000;
}
</style>
