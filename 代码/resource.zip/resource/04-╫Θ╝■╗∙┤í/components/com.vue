<!-- 组件的模板 -->
<template>
<div>
  <p> Component</p>
</div>
</template>

<!-- 组件的 JavaScript -->
<script>
export default {
  name: '',
  data () {
    return {}
  }
}
</script>

<!-- 组件的样式 -->
<style lang="scss" scoped>
  p {
    color: red;
  }
</style>
